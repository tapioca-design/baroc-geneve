myApp.controller('HeaderController', ['$rootScope','$scope','$http',"$route", '$location','$routeParams','$route','Data','Search','Const', function($rootScope, $scope, $http, $route, $location, $routeParams,$route, Data, Search, Const) {




alert("try lsTest = "+localStorage.getItem("lastname"));

if(typeof(Storage) !== "undefined") {
    // Code for localStorage/sessionStorage.
    // Store
      localStorage.setItem("lastname", "Genàve");
      // Retrieve
      var lsTest = localStorage.getItem("lastname");
      //localStorage.removeItem("lastname");
      alert("just assigned lsTest = "+lsTest);
} else {
    // Sorry! No Web Storage support..
    alert("no Storage available");
}







      
      $scope.back = function () {
      console.log("backkkkk from header");
        // var prevUrl = history.length > 1 ? history.splice(-2)[0] : "/";
        // $location.path(prevUrl);
    };

      $scope.Data = Data;
      $scope.Search = Search;
      $scope.Const = Const;
      $scope.searchAllowed = Data.searchAllowed;
      $scope.searchActive = Data.searchActive;
      $scope.back={};
      $scope.back.url = ""
      $rootScope.$on('$locationChangeStart',function(evt, absNewUrl, absOldUrl) {
                  // console.log('start', evt, absNewUrl, absOldUrl);
                  $scope.back.url = absOldUrl;
              });
      $rootScope.$on('$locationChangeSuccess',function(evt, absNewUrl, absOldUrl) {
                  // console.log('success', evt, absNewUrl, absOldUrl);
                  $scope.back.url = absOldUrl;
              });

      $scope.$on('$routeChangeStart', function(event, next, current) {

              // console.log("$location.url()");
              // console.log($location.url());

              $rootScope.$on('$stateChangeSuccess', function (ev, to, toParams, from, fromParams) {

                 // $state.href(from, fromParams)

              });
              Search.term = "";

             if (next && next.$$route && next.$$route.controller) {
                var viewController = next.$$route.controller;
             } else {
                var viewController = "";
             }
              
              if (viewController=="ConcertsListController")  {
                  $scope.headerSideBtnLeftActive = 1;
                  $scope.searchAllowed=1;
                  // $scope.searchActive = 0;
              } else if (viewController=="PlacesListController")  {
                  $scope.headerSideBtnLeftActive = 0;
                  $scope.searchAllowed=0;
              } else if (viewController=="ConcertController")  {
                  $scope.headerSideBtnLeftActive = 1;
                  $scope.searchAllowed=0;
                  $scope.searchActive = 0;
              } else if (viewController=="PlaceController")  {
                  $scope.headerSideBtnLeftActive = 1;
                  $scope.searchAllowed=0;
                  $scope.searchActive = 0;
              } else if (viewController=="MapController")  {
                  $scope.headerSideBtnLeftActive = 0;
                  $scope.searchAllowed=1;
                  $scope.searchActive = 0;
              } else if (viewController=="PlaceMapController")  {
                  $scope.headerSideBtnLeftActive = 1;
                  $scope.searchAllowed=0;
                  $scope.searchActive = 0;
              } else {
                  console.log("NO ROUTE SUPPOSED TO END UP HERE !!!");
                  $scope.headerSideBtnLeftActive = 0;
                  $scope.searchAllowed=1;

              }
      });

      //$scope.Data = Data;
      $scope.searchActiveToggle = function() {
          Data.searchActive = !Data.searchActive;
          $scope.searchActive = Data.searchActive;
          
          //console.log("searchActive"+$scope.searchActive);
      };

      // $scope.$watch(Data, function(newValue, oldValue) {
      //     console.log("change!");
      // }, true);

}]);
