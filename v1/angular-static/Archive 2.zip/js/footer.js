myApp.controller('FooterController', ['$rootScope','$scope','$http',"$route", 'Data', function($rootScope, $scope, $http, $route, Data) {
     //  $scope.$on('$routeChangeStart', function(next, current) { 

     //      var currentViewController = current.$$route.controller;
          
     //      if (currentViewController=="ConcertsListController" || currentViewController=="PlacesListController")  {
     //          $scope.listClass="";
			  // $scope.mapClass="";
     //          $scope.placeClass="";

     //      } else if (currentViewController=="ConcertController")  {
              

     //      } else if (currentViewController=="PlaceController")  {
              
              
     //      } else {
     //          console.log("ERROR from footer, url should not end up here");
     //      }
     //  });

     //  $scope.Data = Data;
     //  $scope.searchShowHideToggle = function() {
     //      $scope.searchShowHideToggleBoolean = !$scope.searchShowHideToggleBoolean;
          
     //  };
}]);